#include "zf_common_headfile.h"

uint8 buzzer_on_flag;//������������־
uint16 buzzer_time_count;//��������ʱ

void buzzer_on(void)
{
	gpio_set_level(B11,1);
}

void buzzer_off(void)
{
	gpio_set_level(B11,0);
}
//������
void buzzer_warning(void)
{
	if(0 == buzzer_on_flag)
	{
		buzzer_on();
		buzzer_on_flag = 1;
	}
}

void buzzer_count(void)
{
	if(1 == buzzer_on_flag)		
	{
		buzzer_time_count ++;
		if(buzzer_time_count >= 50)
		{
			buzzer_on_flag = 0;
			buzzer_time_count = 0;
			buzzer_off();
		}
	}
}