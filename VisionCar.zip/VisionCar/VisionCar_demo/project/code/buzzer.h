#ifndef __BUZZER_H__
#define __BUZZER_H__

void buzzer_warning(void);
void buzzer_count(void);

#endif

