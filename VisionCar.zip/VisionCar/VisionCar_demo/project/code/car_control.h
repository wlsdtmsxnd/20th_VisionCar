#ifndef __CAR_CONTROL_H__
#define __CAR_CONTROL_H__
#include "zf_common_headfile.h"

//����������Ľṹ��
typedef struct {
	int16 basic_speed;
	int16 roundabout_speed;
	int16 finish_push_box_speed;
	float push_box_speed;
	float back_to_track_speed;
	float back_track_Distance;
	float rotation_correct_Kp;
	float rotation_Kp;
	
} Different_Code;


void car_control();
int16 get_v_actual(int16 v[3], int16 theta);

#endif

