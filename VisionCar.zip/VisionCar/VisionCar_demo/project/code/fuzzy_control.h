#ifndef __FUZZY_CONTROL_H__
#define __FUZZY_CONTROL_H__

void multi_gear_deceleration_fuzzy(void);

#endif
