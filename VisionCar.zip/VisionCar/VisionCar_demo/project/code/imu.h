#ifndef CODE_IMU_H_
#define CODE_IMU_H_




extern float GyroOffset_Xdata;
extern float GyroOffset_Ydata;
extern float GyroOffset_Zdata;
extern float GyroOffset_Xdata, icm_data_acc_x, icm_data_gyro_x;
extern float GyroOffset_Ydata, icm_data_acc_y, icm_data_gyro_y;
extern float GyroOffset_Zdata, icm_data_acc_z, icm_data_gyro_z;
extern float M_eulerAngle_yaw, M_eulerAngle_roll, M_eulerAngle_pitch;
extern float M_eulerAngle_yaw_old, M_eulerAngle_yaw_total;
extern float start_angle;
extern float Q_info_q0, Q_info_q1, Q_info_q2, Q_info_q3;

void imu_init(void);
void gyroOffset_init(void);
void ICM_getEulerianAngles(void);
void ICM_AHRSupdate(float gx, float gy, float gz, float ax, float ay, float az);

#endif /* CODE_IMU_H_ */
