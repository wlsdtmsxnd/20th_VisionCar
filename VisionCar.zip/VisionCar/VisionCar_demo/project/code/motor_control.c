#include "zf_common_headfile.h"

//�ٶȻ�
PID_t motor1_speed_pid = {	
	.Kp = 13,
	.Ki = 3.8,
	.Kd = 0,
	.OutMax = 8000,
	.OutMin = -8000,
};
PID_t motor2_speed_pid = {	
	.Kp = 13,
	.Ki = 3.8,
	.Kd = 0,
	.OutMax = 8000,
	.OutMin = -8000,
};
PID_t motor3_speed_pid = {	
	.Kp = 13,
	.Ki = 3.8,
	.Kd = 0,
	.OutMax = 8000,
	.OutMin = -8000,
};


extern int16 v[3];
extern int16 encoder_data[3];

void motor_control()
{	
	motor1_speed_pid.Target = func_limit(v[0],300);
	motor2_speed_pid.Target = func_limit(v[1],300);
	motor3_speed_pid.Target = func_limit(v[2],300);
	
	motor1_speed_pid.Actual = encoder_data[0];
	motor2_speed_pid.Actual = encoder_data[1];
	motor3_speed_pid.Actual = encoder_data[2];
	
	incremental_pid_update(&motor1_speed_pid);	
	incremental_pid_update(&motor2_speed_pid);	
	incremental_pid_update(&motor3_speed_pid);	
	
	motor_set_duty(MOTOR1, motor1_speed_pid.Out);
	motor_set_duty(MOTOR2, motor2_speed_pid.Out);
	motor_set_duty(MOTOR3, motor3_speed_pid.Out);
	
//	motor_set_duty(MOTOR2,1000);
//	motor_set_duty(MOTOR2, speed_pid.Out);
//	motor_set_duty(MOTOR3, speed_pid.Out);


}