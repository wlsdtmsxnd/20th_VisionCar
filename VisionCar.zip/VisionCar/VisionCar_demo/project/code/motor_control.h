#ifndef __MOTOR_CONTROL_H__
#define __MOTOR_CONTROL_H__
#include "zf_common_headfile.h"
#include "my_motor.h"

int16 Incremental_PID (motor_num_enum motor_num, int16 Encoder, int16 Target);
void three_wheels(int16 v_actual, int16 theta, int16 angular_v);
void three_wheels_xy(float v_x, float v_y, float angular_v);
float w_PID(float Target_w, float w);
float Angle_PID(float Target_Angle, float Angle);
void motor_control();

#endif

