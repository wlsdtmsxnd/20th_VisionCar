#ifndef __MY_ENCODER_H__
#define __MY_ENCODER_H__


#define ENCODER_1                       (QTIMER2_ENCODER2)				//���µ��
#define ENCODER_1_LSB                   (QTIMER2_ENCODER2_CH1_C5)
#define ENCODER_1_DIR                   (QTIMER2_ENCODER2_CH2_C25)

#define ENCODER_2                       (QTIMER1_ENCODER1)				//���ϵ��
#define ENCODER_2_LSB                   (QTIMER1_ENCODER1_CH1_C0)
#define ENCODER_2_DIR                   (QTIMER1_ENCODER1_CH2_C1)
                                        
#define ENCODER_3                       (QTIMER1_ENCODER2)				
#define ENCODER_3_LSB                   (QTIMER1_ENCODER2_CH1_C2)
#define ENCODER_3_DIR                   (QTIMER1_ENCODER2_CH2_C24)
                                                                           
#define ENCODER_4                       (QTIMER3_ENCODER2)				//���ϵ��
#define ENCODER_4_LSB                   (QTIMER3_ENCODER2_CH1_B18)
#define ENCODER_4_DIR                   (QTIMER3_ENCODER2_CH2_B19)


void my_encoder_init(void);
void encoder_get(void);

#endif

