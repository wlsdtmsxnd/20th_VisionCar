#ifndef __MY_FLASH_H__
#define __MY_FLASH_H__
#include "zf_common_headfile.h"


void write_identified_data_to_buffer(void);
void read_buffer_to_identified_data(void);

#endif

