#ifndef __MY_FUNCTION_H__
#define __MY_FUNCTION_H__
#include "zf_common_headfile.h"

void My_Delay(int time);
float floatClamp(float value, float min_val, float max_val);
uint8 find_extreme_value(uint8 *array_value, uint8 num0,uint8 num1, uint8 model);
void connect_point(uint8 *array_value, uint8 num0, uint8 num1);
uint8 count_lose_point(uint8 *array_value, uint8 start_idx, uint8 end_idx, uint8 target_value);
uint8 find_jump_point(uint8 *array_value, uint8 num0, uint8 num1, uint8 jump_num, uint8 mode1);
int my_abs(int value);
int max(int a, int b);
void copyColumn(int* source, uint8 rows, uint8 cols, uint8 column, int* target);
float invSqrt(float x);
uint8 findDominantElement(uint8* arr, uint8 length);
uint8 calculateDiff(uint8 arr[], uint8 length);
uint8 findNonZeroMinMax(uint8 arr[], uint8 length, uint8* min_val, uint8* max_val);
#endif

