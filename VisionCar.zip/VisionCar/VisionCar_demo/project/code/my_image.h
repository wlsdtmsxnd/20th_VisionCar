#ifndef __MY_IMAGE_H__
#define __MY_IMAGE_H__

#define image_W 188
#define image_H 80

#define USER_IMAGE bin_image[0]
//#define USER_IMAGE image_copy[0]
//#define MY_IMAGE inverse_perspective_image[0]

void my_image_init(void);


#endif



