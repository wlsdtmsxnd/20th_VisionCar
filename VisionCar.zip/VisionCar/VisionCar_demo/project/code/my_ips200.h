#ifndef __MY_IPS200_H__
#define __MY_IPS200_H__
#include "zf_common_headfile.h"

void my_ips200_init();


#endif

