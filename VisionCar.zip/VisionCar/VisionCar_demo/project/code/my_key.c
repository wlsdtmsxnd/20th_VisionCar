#include "zf_common_headfile.h"


uint8_t key_getnum(void)
{
	uint8_t KeyNum;
	
	key_scanner();

	if(KEY_SHORT_PRESS == key_get_state(KEY_1))		
		KeyNum = 1;
	else if(KEY_SHORT_PRESS == key_get_state(KEY_2))
		KeyNum = 2;
	else if(KEY_SHORT_PRESS == key_get_state(KEY_3))
		KeyNum = 3;
	else if(KEY_SHORT_PRESS == key_get_state(KEY_4))
		KeyNum = 4;
	else
		KeyNum = 0;

	key_clear_all_state();
	
	return KeyNum;
}