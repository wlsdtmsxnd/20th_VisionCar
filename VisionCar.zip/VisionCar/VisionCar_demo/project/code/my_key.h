#ifndef __MY_KEY_H__
#define __MY_KEY_H__

#include "zf_common_headfile.h"

uint8_t key_getnum(void);

#endif
