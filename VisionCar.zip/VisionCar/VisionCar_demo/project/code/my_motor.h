#ifndef __MY_MOTOR_H__
#define __MY_MOTOR_H__
#include "zf_common_headfile.h"

#define MOTOR1_DIR               (D3 )											//��Ӧ���ϵ��
#define MOTOR1_PWM               (PWM2_MODULE3_CHA_D2)

#define MOTOR2_DIR               (C7 )											//��Ӧ���ϵ��
#define MOTOR2_PWM               (PWM2_MODULE0_CHA_C6)

#define MOTOR3_DIR               (C11 )											//��Ӧ���µ��
#define MOTOR3_PWM               (PWM2_MODULE2_CHA_C10)

typedef enum
{
	MOTOR1 = 1,
	MOTOR2,
	MOTOR3
}motor_num_enum;

void my_motor_init();
void motor_set_duty(motor_num_enum motor_num, int16 duty);

#endif

