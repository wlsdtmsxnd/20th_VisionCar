#ifndef __MY_UART_H__
#define __MY_UART_H__


#define UART_PRIORITY           (LPUART1_IRQn)                                  // ��Ӧ�����жϵ��жϱ�� �� MIMXRT1064.h ͷ�ļ��в鿴 IRQn_Type ö����
#define RED_BOX_X    			uart1_data_arr[0]
#define RED_BOX_Y    			uart1_data_arr[1]
#define RED_BOX_W    			uart1_data_arr[2]
#define RED_BOX_H				uart1_data_arr[3]
#define RED_BOX_LEFT_POINT		uart1_data_arr[4]
#define RED_BOX_RIGHT_POINT		uart1_data_arr[5]

void my_uart_init(void);

#endif