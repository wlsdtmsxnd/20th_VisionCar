#include "zf_common_headfile.h"


extern FireWater_Struct FW_Data[CH_COUNT];
extern int16 encoder_data[3];
extern PID_t motor1_speed_pid;
extern int16 v[3];
extern PID_t turn_pid;

seekfree_assistant_oscilloscope_struct oscilloscope_data;
float parameter[8];	
	
void my_wireless_uart_init(void)
{
	//ʹ��������ִ�������ʱ��,�����wifi��ͻ
    // ��ʼ������ת����
    wireless_uart_init();
    // �����������ʹ������ת���ڽ����շ�
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIRELESS_UART);
    // ��ʼ���������ʾ�����Ľṹ��

//    oscilloscope_data.data[0] = 0.1111 + 2;
//    oscilloscope_data.data[1] = 0.3333 - 1;
//    oscilloscope_data.data[2] = 4.222;
//    oscilloscope_data.data[3] = 5.222;
    // ����Ϊ4��ͨ����ͨ���������Ϊ8��
    oscilloscope_data.channel_num = 4;
}

void pass_parameter()
{

}
void uart_update(void)
{
	//����ÿ��ͨ���Ĳ���
	oscilloscope_data.data[0] = turn_pid.Error0;//��ʱ��Ϊ��
	oscilloscope_data.data[1] = turn_pid.Error0 - turn_pid.Error1;//��x��
//	oscilloscope_data.data[2] = M_eulerAngle_yaw;//��z��
//	oscilloscope_data.data[3] = M_eulerAngle_roll;
//	oscilloscope_data.data[4] = encoder_data[0];
//	oscilloscope_data.data[5] = encoder_data[0];
//	oscilloscope_data.data[6] = encoder_data[0];
//	oscilloscope_data.data[7] = encoder_data[0];
	//���ڵ��β���		
	seekfree_assistant_data_analysis();

	// ����
	for(uint8_t i = 0; i < SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT; i++)
	{
		// ���±�־λ
		if(seekfree_assistant_parameter_update_flag[i])
		{
			parameter[i] = seekfree_assistant_parameter[i];
			motor1_speed_pid.Kp = seekfree_assistant_parameter[0];
			motor1_speed_pid.Ki = seekfree_assistant_parameter[1];
			v[0] = seekfree_assistant_parameter[2];
		}
		
	}    	
	// ͨ������ת���ڷ��͵�����ʾ������
	seekfree_assistant_oscilloscope_send(&oscilloscope_data);
}


//extern float w;
//extern uint8 image_thereshold;
//extern int32 now_position[3];
//extern int32 Target_position[3];
//void pit_handler_3()
//{

//	FW_Data[0].type = 'd';
//	FW_Data[1].type = 'd';
//	FW_Data[2].type = 'd';
//	FW_Data[3].type = 'd';
//	FW_Data[4].type = 'd';
//	FW_Data[5].type = 'd';
//	FW_Data[6].type = 'f';
//	FW_Data[7].type = 'f';
//	FW_Data[8].type = 'f';
//	FW_Data[9].type = 'f';
//	FW_Data[10].type = 'f';
//	FW_Data[11].type = 'd';
//	FW_Data[12].type = 'd';
//	FW_Data[13].type = 'd';
//	FW_Data[14].type = 'd';
//	

//	FW_Data[0].int_data = encoder_data[0];
//	FW_Data[1].int_data = encoder_data[1];
//	FW_Data[2].int_data = encoder_data[2];
////	FW_Data[0].int_data = Target_position[0];
////	FW_Data[1].int_data = Target_position[1];
////	FW_Data[2].int_data = Target_position[2];
//	FW_Data[3].int_data = v[0];
//	FW_Data[4].int_data = v[1];
//	FW_Data[5].int_data = v[2];
////	FW_Data[7].float_data = Target_imu963_data;
////	FW_Data[8].float_data = w;
////	FW_Data[9].float_data = now_angle;
////	FW_Data[10].float_data = Target_angle;
////	FW_Data[11].int_data = image_thereshold;
////	FW_Data[12].int_data = now_position[0];
////	FW_Data[13].int_data = now_position[1];
////	FW_Data[14].int_data = now_position[2];
//	
//	FireWater_Send();
//	
//	//ʹ���������wifi������ʱ��
////	oscilloscope_data.data[0] = now_angle;
////	oscilloscope_data.data[1] = v[1];
////	oscilloscope_data.data[2] = v[2];
////	oscilloscope_data.data[3] = RC_encoder_data[0];
////	oscilloscope_data.data[4] = w;
////	oscilloscope_data.data[5] = Target_imu963_data;
////	oscilloscope_data.data[6] = imu_data.gyro_z;
////	oscilloscope_data.data[7] = RC_imu963_data;
////	seekfree_assistant_oscilloscope_send(&oscilloscope_data);
//}