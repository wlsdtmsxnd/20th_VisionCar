#ifndef __MY_WIRELESS_UART_H__
#define __MY_WIRELESS_UART_H__


void my_wireless_uart_init(void);
void uart_update(void);
	

#endif

