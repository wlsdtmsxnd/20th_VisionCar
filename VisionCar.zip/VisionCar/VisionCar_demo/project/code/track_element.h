#ifndef __TRACK_ELEMENT_H__
#define __TRACK_ELEMENT_H__

void cross_element(void);
void roundabout_element(void);
void zebra_crossing(void);

#endif

