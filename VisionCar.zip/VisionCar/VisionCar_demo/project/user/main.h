#ifndef __MAIN_H__
#define __MAIN_H__

void My_Delay(int time);
void buzzer_warning(void);

#endif

