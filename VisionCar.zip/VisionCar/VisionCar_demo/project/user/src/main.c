#include "zf_common_headfile.h"

uint8 keynum;//����
uint8 START;//����
uint8 END;//����
uint8 Page = 1;//ҳ��
uint8 turn_page_flag;//��ҳ��־λ
uint8 save_flash_flag;//����flash���ݱ�־λ,����

//������������
extern uint8 current_mode_idx;  					//������������0-2��
extern Different_Code Speed_Mode[3];				//�ٶȵ�λ

//������ʾ
extern  uint8 xiangzi[4][16];
extern  uint8 shubiao[4][16];
extern  uint8 banshou[4][16];
extern  uint8 jianpan[4][16];
extern  uint8 luosidao[6][16];
extern  uint8 xianshiqi[6][16];
extern  uint8 shoudianzuan[6][16];
extern  uint8 erji[4][16];
extern  uint8 qianzi[4][16];
extern  uint8 yinxiang[4][16];
extern  uint8 wanyongbiao[6][16];
extern  uint8 dayinji[6][16];
extern  uint8 shiboqi[6][16];
extern  uint8 shouji[4][16];
extern  uint8 dianlaotie[6][16];
extern  uint8 juanchi[4][16];

//-------------------------------------------------�������ڵ�����ʾ
extern uint16 uart1_data_arr[6];
extern uint8 identified_data[24];//��ȷ��ʶ�������
extern uint8 box_num;//�������

extern uint8 Control_Mode;
extern uint8 move_Mode;
extern float M_eulerAngle_yaw_total;

extern int16 Speed;
extern int16 Theta;
extern float V_x, V_y;

extern int32 Distance;
extern int16 err_y, err_x;
extern float V_x;
extern float V_y;
extern float W;
extern int16 encoder_data[3];
extern int16 v[3];
extern int16 close_box_Speed;

extern float Slope;
extern PID_t motor1_speed_pid;
extern PID_t turn_pid;
extern uint8 left_lost_point;
extern uint8 right_lost_point;

extern uint8 cross_flag;							
extern uint8 roundabout_flag;						
extern uint8 zebra_flag;

extern uint8 uart4_data_used;
extern float left_line_curvity;
extern float right_line_curvity;
extern uint16 left_dir_1;
extern uint16 right_dir_1;

extern uint8 left_jump_point_15_40;
extern uint8 right_jump_point_15_40;
extern uint8 left_jump_point_60_40;
extern uint8 right_jump_point_60_40;
extern uint8 left_lose_point_num_5_40;
extern uint8 right_lose_point_num_5_40;
extern uint8 left_lose_point_num_20_75;
extern uint8 right_lose_point_num_20_75;


//����
void key_execute(void)
{
	keynum = key_getnum();
	
	if(1 == Page)//ʶ����ʾ+����
	{
		switch(keynum)
		{
			case 1:
				START = 1;
			break;
			case 2:
				if(3 == current_mode_idx)
					current_mode_idx = 0;
				else
					current_mode_idx ++;
			break;
			case 3:
				if(0 == current_mode_idx)
					current_mode_idx = 3;
				else
					current_mode_idx --;
			break;
			case 4:
				Page = 2;
				turn_page_flag = 1;
			break;		
		}		
	}
	else if(2 == Page)
	{
		switch(keynum)
		{
			case 1:
				
			break;
			case 2:
				
			break;
			case 3:
				if(save_flash_flag)
					save_flash_flag = 0;
				else 
					save_flash_flag = 1;
			break;
			case 4:
				Page = 1;
				turn_page_flag = 1;
			break;		
		}		
	}
}

void ips200_show(void)
{
	if(1 == Page)
	{
		if(turn_page_flag)
		{
			ips200_clear();
			turn_page_flag = 0;
		}	
		ips200_show_float(120, 180, M_eulerAngle_yaw_total, 3, 1);
		ips200_show_int	 (120, 210, zebra_flag, 1);
		ips200_show_int  (120, 240, roundabout_flag, 1);	
		ips200_show_int  (120, 270, Control_Mode, 1);
		ips200_show_string(120, 300, "Spd");
		ips200_show_int	 (145, 300, Speed_Mode[current_mode_idx].basic_speed, 3);
		ips200_show_string(185, 300, "Page");
		ips200_show_int	  (220, 300, Page, 1);

	//-------------------------------------------------------------------������ʾʶ����Ϣ
		ips200_show_chinese(0, 0, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 20, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 40, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 60, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 80, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 100, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 120, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 140, 16, xiangzi[0], 2, RGB565_WHITE);			
		ips200_show_chinese(0, 160, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 180, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 200, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 220, 16, xiangzi[0], 2, RGB565_WHITE);	
		ips200_show_chinese(0, 240, 16, xiangzi[0], 2, RGB565_WHITE);			
		ips200_show_chinese(0, 260, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 280, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(0, 300, 16, xiangzi[0], 2, RGB565_WHITE);

		ips200_show_int(33,0,1,1);
		ips200_show_int(33,20,2,1);
		ips200_show_int(33,40,3,1);
		ips200_show_int(33,60,4,1);
		ips200_show_int(33,80,5,1);
		ips200_show_int(33,100,6,1);
		ips200_show_int(33,120,7,1);
		ips200_show_int(33,140,8,1);
		ips200_show_int(33,160,9,1);
		ips200_show_int(33,180,10,2);										
		ips200_show_int(33,200,11,2);
		ips200_show_int(33,220,12,2);
		ips200_show_int(33,240,13,2);
		ips200_show_int(33,260,14,2);
		ips200_show_int(33,280,15,2);
		ips200_show_int(33,300,16,2);
		
		ips200_show_char(40, 0, ':');
		ips200_show_char(40, 20, ':');		
		ips200_show_char(40, 40, ':');		
		ips200_show_char(40, 60, ':');		
		ips200_show_char(40, 80, ':');
		ips200_show_char(40, 100, ':');		
		ips200_show_char(40, 120, ':');		
		ips200_show_char(40, 140, ':');	
		ips200_show_char(40, 160, ':');
		ips200_show_char(50, 180, ':');		
		ips200_show_char(50, 200, ':');		
		ips200_show_char(50, 220, ':');	
		ips200_show_char(50, 240, ':');
		ips200_show_char(50, 260, ':');		
		ips200_show_char(50, 280, ':');		
		ips200_show_char(50, 300, ':');

		for(uint8 i = 0; i < 16; i ++)
		{
			if(0 < identified_data[i] && identified_data[i] < 100)
				ips200_show_int(70, 20*i, identified_data[i], 2);
			else if(100 == identified_data[i])
				ips200_show_int(70, 20*i, 0, 2);
			else
			{			
				switch(identified_data[i])
				{
					case 101:
						ips200_show_chinese(70, 20*i, 16, shubiao[0], 2, RGB565_WHITE);
					break;
					
					case 102:
						ips200_show_chinese(70, 20*i, 16, banshou[0], 2, RGB565_WHITE);
					break;
					
					case 103:
						ips200_show_chinese(70, 20*i, 16, jianpan[0], 2, RGB565_WHITE);
					break;
					
					case 104:
						ips200_show_chinese(70, 20*i, 16, luosidao[0], 3, RGB565_WHITE);	
					break;
					
					case 105:
						ips200_show_chinese(70, 20*i, 16, xianshiqi[0], 3, RGB565_WHITE);
					break;
					
					case 106:
						ips200_show_chinese(70, 20*i, 16, shoudianzuan[0], 3, RGB565_WHITE);
					break;
					
					case 107:
						ips200_show_chinese(70, 20*i, 16, erji[0], 2, RGB565_WHITE);
					break;
					
					case 108:
						ips200_show_chinese(70, 20*i, 16, qianzi[0], 2, RGB565_WHITE);	
					break;
					
					case 109:
						ips200_show_chinese(70, 20*i, 16, yinxiang[0], 2, RGB565_WHITE);
					break;
					
					case 110:
						ips200_show_chinese(70, 20*i, 16, wanyongbiao[0], 3, RGB565_WHITE);
					break;
					
					case 111:
						ips200_show_chinese(70, 20*i, 16, dayinji[0], 3, RGB565_WHITE);
					break;
					
					case 112:
						ips200_show_chinese(70, 20*i, 16, shiboqi[0], 3, RGB565_WHITE);
					break;
					
					case 113:
						ips200_show_chinese(70, 20*i, 16, shouji[0], 2, RGB565_WHITE);
					break;
					
					case 114:
						ips200_show_chinese(70, 20*i, 16, dianlaotie[0], 3, RGB565_WHITE);
					break;
					
					case 116:
						ips200_show_chinese(70, 20*i, 16, juanchi[0], 2, RGB565_WHITE);					
					break;
					
					default:
					break;	
				}		
			}
		}
		
		ips200_draw_line(118, 0, 118, 319, RGB565_WHITE);
		
		ips200_show_chinese(120, 0, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 20, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 40, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 60, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 80, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 100, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 120, 16, xiangzi[0], 2, RGB565_WHITE);
		ips200_show_chinese(120, 140, 16, xiangzi[0], 2, RGB565_WHITE);			

		ips200_show_int(153,0,17,2);
		ips200_show_int(153,20,18,2);
		ips200_show_int(153,40,19,2);
		ips200_show_int(153,60,20,2);
		ips200_show_int(153,80,21,2);
		ips200_show_int(153,100,22,2);
		ips200_show_int(153,120,23,2);
		ips200_show_int(153,140,24,2);
		
		ips200_show_char(170, 0, ':');
		ips200_show_char(170, 20, ':');		
		ips200_show_char(170, 40, ':');		
		ips200_show_char(170, 60, ':');		
		ips200_show_char(170, 80, ':');
		ips200_show_char(170, 100, ':');		
		ips200_show_char(170, 120, ':');		
		ips200_show_char(170, 140, ':');	

		for(uint8 i = 16; i < 24; i ++)
		{
			if(0 < identified_data[i] && identified_data[i] < 100)
				ips200_show_int(190, 20*(i-16), identified_data[i], 2);
			else if(100 == identified_data[i])
				ips200_show_int(190, 20*i, 0, 2);
			else
			{			
				switch(identified_data[i])
				{
					case 101:
						ips200_show_chinese(190, 20*(i-16), 16, shubiao[0], 2, RGB565_WHITE);
					break;

					case 102:
						ips200_show_chinese(190, 20*(i-16), 16, banshou[0], 2, RGB565_WHITE);
					break;
					
					case 103:
						ips200_show_chinese(190, 20*(i-16), 16, jianpan[0], 2, RGB565_WHITE);
					break;
					
					case 104:
						ips200_show_chinese(190, 20*(i-16), 16, luosidao[0], 3, RGB565_WHITE);	
					break;
					
					case 105:
						ips200_show_chinese(190, 20*(i-16), 16, xianshiqi[0], 3, RGB565_WHITE);
					break;
					
					case 106:
						ips200_show_chinese(190, 20*(i-16), 16, shoudianzuan[0], 3, RGB565_WHITE);
					break;
					
					case 107:
						ips200_show_chinese(190, 20*(i-16), 16, erji[0], 2, RGB565_WHITE);
					break;
					
					case 108:
						ips200_show_chinese(190, 20*(i-16), 16, qianzi[0], 2, RGB565_WHITE);	
					break;
					
					case 109:
						ips200_show_chinese(190, 20*(i-16), 16, yinxiang[0], 2, RGB565_WHITE);
					break;
					
					case 110:
						ips200_show_chinese(190, 20*(i-16), 16, wanyongbiao[0], 3, RGB565_WHITE);
					break;
					
					case 111:
						ips200_show_chinese(190, 20*(i-16), 16, dayinji[0], 3, RGB565_WHITE);
					break;
					
					case 112:
						ips200_show_chinese(190, 20*(i-16), 16, shiboqi[0], 3, RGB565_WHITE);
					break;
					
					case 113:
						ips200_show_chinese(190, 20*(i-16), 16, shouji[0], 2, RGB565_WHITE);
					break;
					
					case 114:
						ips200_show_chinese(190, 20*(i-16), 16, dianlaotie[0], 3, RGB565_WHITE);
					break;
					
					case 116:
						ips200_show_chinese(190, 20*(i-16), 16, juanchi[0], 2, RGB565_WHITE);					
					break;
					
					default:
					break;	
				}		
			}
		}				
	}
	else if(2 == Page)
	{
		if(turn_page_flag)
		{
			ips200_clear();
			turn_page_flag = 0;
		}
		
		ips200_show_string(0,0,"save flash memory ?");
		if(save_flash_flag) 
			ips200_show_string(0,20,"yes");
		else 
			ips200_show_string(0,20,"no ");
		
		ips200_show_string(120, 300, "Spd");
		ips200_show_int	 (145, 300, Speed_Mode[current_mode_idx].basic_speed, 3);
		ips200_show_string(185, 300, "Page");
		ips200_show_int	  (220, 300, Page, 1);
	}
}
int main(void)
{
	clock_init(SYSTEM_CLOCK_600M);  // ����ɾ��
    debug_init();                   // ���Զ˿ڳ�ʼ��
	
	system_delay_ms (300);			//��������ʹ����CR���ſ����ϵ�ʱ��,��Ҫ��ʱһ��ʱ����ܲ�������
	
    gpio_init(B11, GPO, GPIO_LOW, GPO_PUSH_PULL);	
	gpio_init(B10, GPI, GPIO_LOW, GPI_PULL_UP);	
	my_ips200_init();
	key_init(5);	
	flash_init();
	my_motor_init();
	my_encoder_init();
	imu_init();    
    // �Ƽ��ȳ�ʼ������ͷ�����ʼ���������
    my_image_init();
//	my_wifi_init();
//	seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIFI_SPI);
//	my_wireless_uart_init();
	my_uart_init(); 
	
	interrupt_set_priority(PIT_IRQn, 0);
	interrupt_set_priority(LPUART1_IRQn,1);
	interrupt_set_priority(LPUART4_IRQn,2);	
	
	interrupt_global_enable(0);
	
	uart_rx_interrupt(UART_1, ZF_ENABLE);  
	uart_rx_interrupt(UART_4, ZF_ENABLE);  

	pit_ms_init(PIT_CH1, 5);	//������
	pit_ms_init(PIT_CH2, 5);	//�����
	pit_ms_init(PIT_CH3, 5);	//uart������,������

	buzzer_warning();
	
	while(0 == START)
	{
		key_execute();
		ips200_show();

	}	
	Page = 1;
	if(save_flash_flag)
	{
		read_buffer_to_identified_data();
	}	
	pit_ms_init(PIT_CH0, 5);	//������
	
	while(1)
    {
		ips200_show();
		if(END)
		{
			END = 0;
			interrupt_global_enable(1);//�ر�ȫ���ж�,д��flash
			write_identified_data_to_buffer();
		}
	}
}

