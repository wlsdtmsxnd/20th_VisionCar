import sensor, image, time
from machine import UART
import json
import seekfree, pyb

sensor.reset()
sensor.set_pixformat(sensor.RGB565) # 设置图像色彩为RGB565
sensor.set_framesize(sensor.QVGA)   # 设置图像格式为QVGA （320*240）
sensor.set_framerate(60)            # 设置帧率为60帧  可以填写2、8、15、30、50、60
sensor.set_auto_whitebal(False)      # 设置自动白平衡
sensor.skip_frames(time = 200)      # 跳过200帧，摄像头设置参数后需要跳过一定帧率
sensor.set_vflip(True)  # 垂直翻转图像
sensor.set_hmirror(True)  # 水平翻转图像
clock = time.clock()

#外设初始化_______________________________________________________________________
# 初始化串口 波特率设置为115200  如果硬件版本是1.4，需要改成UART(1, baudrate=115200)
uart = UART(2, baudrate=115200)
# 3：屏幕显示方向 参数范围0-3
lcd = seekfree.IPS200(3)
lcd.full()  # 将背景颜色显示到整个屏幕

#数据初始化_______________________________________________________________________
# 红箱子阈值
red_threshold = (24, 61, 34, 121, -86, 93)
# 初始化roi,(x, y, w, h)
current_roi = (0, 0, 320, 240)

# 找最大色块
def find_max(blobs):
    max_size=0
    for blob in blobs:
        if blob.pixels() > max_size:
            max_blob=blob
            max_size = blob.pixels()
    return max_blob

# 确保ROI在有效范围内
def clamp_roi(roi):
    x = max(0, roi[0])
    y = max(0, roi[1])
    w = min(320-x, roi[2])
    h = min(240-y, roi[3])
    return (x, y, w, h)

while(True):
    img = sensor.snapshot()

    blobs = img.find_blobs([red_threshold])
    if blobs:
        max_blob=find_max(blobs)
        #print('sum :', len(blobs))
        # 红箱子区域ROI
        red_box_roi = max_blob.rect()
        rx, ry, rw, rh = red_box_roi

        # 红箱子扩展区域ROI（左右各扩展5，上下与红箱子一致）
        expanded_roi = (rx - 5, ry, rw + 10, rh)  # 左右各扩展5个单位，总扩展10个单位
        valid_expanded_roi = clamp_roi(expanded_roi)
        vex, vey, vew, veh = valid_expanded_roi

        # 红箱子区域ROI与红箱子扩展区域ROI的相对坐标
        red_in_expanded = (5, 0, rw, rh)  # 左偏移5，上下0

        # 红箱子扩展区域ROI的灰度图
        gray_roi = img.copy(roi=valid_expanded_roi).to_grayscale()

        #  红箱子区域ROI涂黑（全黑）
        gray_roi.draw_rectangle(red_in_expanded, color=0, fill=True)

        # 分别处理左右扩展区域的二值化
        # 左区域：0~5像素
        left_roi = (0, 0, 5, veh)  # 左区域宽度为5个单位
        left_threshold = gray_roi.copy(roi=left_roi).get_histogram().get_threshold().value()
        left_binary = gray_roi.copy(roi=left_roi).binary([(left_threshold, 255)], invert=False)

        # 右区域：rw+5~vew像素
        right_width = vew - rw - 5  # 右区域宽度计算调整为减5
        if right_width > 0:  # 确保右区域宽度合法
            right_roi = (rw + 5, 0, right_width, veh)  # 右区域起始位置调整为加5
            right_threshold = gray_roi.copy(roi=right_roi).get_histogram().get_threshold().value()
            right_binary = gray_roi.copy(roi=right_roi).binary([(right_threshold, 255)], invert=False)
        else:
            right_binary = image.Image(1, veh, sensor.GRAYSCALE)  # 创建空图像

        img.draw_rectangle(max_blob.rect())
        img.draw_cross(max_blob.cx(), max_blob.cy())

        # 在左右区域中分别寻找最大白色色块
        left_blobs = left_binary.find_blobs([(255, 255)])
        right_blobs = right_binary.find_blobs([(255, 255)])

        # 处理左区域最大色块
        if left_blobs:
            left_max_blob = find_max(left_blobs)
            # 转换为扩展ROI的坐标
            left_x = left_max_blob.cx()
            left_y = left_max_blob.cy()
            left_w = left_max_blob.w()
            left_h = left_max_blob.h()

            img.draw_cross(vex + left_max_blob.x() + left_w, vey + left_max_blob.y(), color=(0, 255, 0))

        # 处理右区域最大色块
        if right_blobs:
            right_max_blob = find_max(right_blobs)
            right_x = rw + 5 + right_max_blob.cx()  # 右区域坐标计算调整为加5
            right_y = right_max_blob.cy()
            right_w = right_max_blob.w()
            right_h = right_max_blob.h()

            img.draw_cross(vex + rw + 5 + right_max_blob.x(), vey + right_max_blob.y(), color=(0, 0, 255))

        left_y = left_max_blob.y() if left_blobs else 0
        right_y = right_max_blob.y() if right_blobs else 0

        output_str="@%d,%d,%d,%d,%d,%d#" % (max_blob.cx(),max_blob.cy(),max_blob.w(),max_blob.h(),left_y,right_y)
        #print("left_y:%d,right_y:%d" % (left_y,right_y))
        #print('you send:',output_str)
        uart.write(output_str+'\r\n')
    #else:
        #print('not found!')

    lcd.show_image(img, 320, 240, zoom=0)
