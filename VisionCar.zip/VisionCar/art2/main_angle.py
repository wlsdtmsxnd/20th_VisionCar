import sensor, image, time
from machine import UART
import math
import seekfree

sensor.reset()
sensor.set_pixformat(sensor.RGB565) # 设置图像色彩为RGB565
sensor.set_framesize(sensor.QVGA)   # 设置图像格式为QVGA （320*240）
sensor.set_framerate(60)            # 设置帧率为60帧  可以填写2、8、15、30、50、60
sensor.set_auto_whitebal(False)      # 设置自动白平衡
sensor.skip_frames(time = 200)      # 跳过200帧，摄像头设置参数后需要跳过一定帧率
sensor.set_vflip(True)  # 垂直翻转图像
sensor.set_hmirror(True)  # 水平翻转图像
clock = time.clock()

#外设初始化_______________________________________________________________________
# 初始化串口 波特率设置为115200  如果硬件版本是1.4，需要改成UART(1, baudrate=115200)
uart = UART(2, baudrate=115200)
# 3：屏幕显示方向 参数范围0-3
lcd = seekfree.IPS200(3)
lcd.full()  # 将背景颜色显示到整个屏幕

#数据初始化_______________________________________________________________________
# 红箱子阈值
red_threshold = (30, 55, 17, 71, 14, 66)
white_threshold = (56, 100, -128, 23, -128, 127)

# 全局变量声明
white_cx = 0  # 白色色块中心点x坐标
white_cy = 0  # 白色色块中心点y坐标
rotation = 0  # 箱子偏移角

# 找最大色块
def find_max(blobs):
    max_size=0
    for blob in blobs:
        if blob.pixels() > max_size:
            max_blob=blob
            max_size = blob.pixels()
    return max_blob

# 确保ROI在有效范围内
def clamp_roi(roi):
    x = max(0, roi[0])
    y = max(0, roi[1])
    w = min(320-x, roi[2])
    h = min(240-y, roi[3])
    return (x, y, w, h)

while(True):
    img = sensor.snapshot()
    #img_copy = img.copy(1,1).lens_corr(strength=1.7, zoom=1.0)

    red_blobs = img.find_blobs([red_threshold],area_threshold=1000)#3600
    if red_blobs:
        red_max_blob = max(red_blobs, key=lambda b: b.pixels())  # 按像素数找最大色块
        rx, ry, rw, rh = red_max_blob.rect()

        find_white_roi = (red_max_blob.x() + 4, red_max_blob.cy() + 1, red_max_blob.w() - 8, red_max_blob.h() // 2 - 2)
        white_blobs = img.find_blobs([white_threshold],roi = find_white_roi)
        if white_blobs:  # 先判断列表非空
            white_max_blob = max(white_blobs, key=lambda b: b.w())  # 按宽度（w()）找最宽
            # 3. 检查最大色块的宽度
            if white_max_blob.w() >= 7:  # 宽度符合要求，保留并处理
                # 获取倾斜角 (弧度)
                rotation = white_max_blob.rotation()
                # 转换为角度 (度)
                angle_degrees = rotation * 180 / 3.14159
                out_angle = int(angle_degrees)
                # 绘制旋转轴
                white_cx, white_cy = white_max_blob.cx(), white_max_blob.cy()
            else:  # 宽度不足时，显式赋值 out_angle=0
                out_angle = 0
            #img_copy.draw_rectangle(white_max_blob.rect())
            #img_copy.draw_cross(white_max_blob.cx(), white_max_blob.cy())
        else:
            #img.draw_line(rx, ry + rh, rx + rw, ry+rh, color=(0, 255, 0), thickness=1)
            out_angle = 0
        print("angle:%d" % out_angle)

        # 红箱子扩展区域ROI（左右各扩展5，上下与红箱子一致）
        expanded_roi = (rx - 5, ry, rw + 10, rh)  # 左右各扩展5个单位，总扩展10个单位
        valid_expanded_roi = clamp_roi(expanded_roi)
        vex, vey, vew, veh = valid_expanded_roi

        # 红箱子区域ROI与红箱子扩展区域ROI的相对坐标
        red_in_expanded = (5, 0, rw, rh)  # 左偏移5，上下0

        # 红箱子扩展区域ROI的灰度图
        gray_roi = img.copy(roi=valid_expanded_roi).to_grayscale()

        #  红箱子区域ROI涂黑（全黑）
        gray_roi.draw_rectangle(red_in_expanded, color=0, fill=True)

        # 分别处理左右扩展区域的二值化
        # 左区域：0~5像素
        left_roi = (0, 0, 5, veh)  # 左区域宽度为5个单位
        left_threshold = gray_roi.copy(roi=left_roi).get_histogram().get_threshold().value()
        left_binary = gray_roi.copy(roi=left_roi).binary([(left_threshold, 255)], invert=False)

        # 右区域：rw+5~vew像素
        right_width = vew - rw - 5  # 右区域宽度计算调整为减5
        if right_width > 0:  # 确保右区域宽度合法
            right_roi = (rw + 5, 0, right_width, veh)  # 右区域起始位置调整为加5
            right_threshold = gray_roi.copy(roi=right_roi).get_histogram().get_threshold().value()
            right_binary = gray_roi.copy(roi=right_roi).binary([(right_threshold, 255)], invert=False)
        else:
            right_binary = image.Image(1, veh, sensor.GRAYSCALE)  # 创建空图像

        # 在左右区域中分别寻找最大白色色块
        left_blobs = left_binary.find_blobs([(255, 255)])
        right_blobs = right_binary.find_blobs([(255, 255)])

        # 处理左区域最大色块
        left_max_blob = None
        if left_blobs:
            left_max_blob = find_max(left_blobs)
            # 转换为扩展ROI的坐标
            left_x = left_max_blob.cx()
            left_y = left_max_blob.cy()
            left_w = left_max_blob.w()
            left_h = left_max_blob.h()

            #img.draw_cross(vex + left_max_blob.x() + left_w, vey + left_max_blob.y(), color=(0, 255, 0))

        # 处理右区域最大色块
        right_max_blob = None
        if right_blobs:
            right_max_blob = find_max(right_blobs)
            right_x = rw + 5 + right_max_blob.cx()  # 右区域坐标计算调整为加5
            right_y = right_max_blob.cy()
            right_w = right_max_blob.w()
            right_h = right_max_blob.h()

            #img.draw_cross(vex + rw + 5 + right_max_blob.x(), vey + right_max_blob.y(), color=(0, 0, 255))

        left_y = left_max_blob.y() if left_max_blob is not None else 0
        right_y = right_max_blob.y() if right_max_blob is not None else 0

        """img.draw_rectangle(red_max_blob.rect(),color = (0, 0, 0))
        img.draw_cross(red_max_blob.cx(), red_max_blob.cy(),color = (0, 0, 0))
        img.draw_line(
            white_cx, white_cy,
            int(white_cx + 50 * math.cos(rotation)),
            int(white_cy + 50 * math.sin(rotation)),
            color=(0, 255, 0), thickness=1
        )"""
        output_str="@%d,%d,%d,%d,%d#" % (red_max_blob.cx(),red_max_blob.h(),left_y,right_y,out_angle)
        #print("left_y:%d,right_y:%d" % (left_y,right_y))
        #print('you send:',output_str)
        uart.write(output_str+'\r\n')
    #else:
        #print('not found!')

    #lcd.show_image(img, 320, 240, zoom=0)
